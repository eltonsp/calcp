cordova.define("appnext-plugin.interstitial", function(require, exports, module) { 	var
		exec = require('cordova/exec'),
		cordova = require('cordova');

	var _f ={
		setCategories:'setCategories',
		setPostback:'setPostback',
		setButtonText:'setButtonText',
		setButtonColor:'setButtonColor',
		setPreferredOrientation:'setOrientation',
		setMute:'setMute',
		setBackButtonCanClose:'setBackButtonCanClose',

		setCreativeType:'setCreativeType',
		setAutoPlay:'setAutoPlay',
		setSkipText:'setSkipText'
	}
	var _callbacks={
		loadAd:'loadAd',
		showAd:'showAd',
		setOnAdClickedCallback:'setOnAdClickedCallback',
		setOnAdErrorCallback:'setOnAdErrorCallback',
		setOnAdLoadedCallback:'setOnAdLoadedCallback',
		setOnAdClosedCallback:'setOnAdClosedCallback'
	}
	function Interstitial(placementId,config) {
	    this.id = "AIId_"+Date.now();
		this.placementId = placementId;
		this.config=config||null;
		exec(function(){}, function(){}, "Interstitial", "create", [this.id, placementId, config]);
	}

	 for (var prop in _f) {
		(function(p) {
			Interstitial.prototype[prop] = function(options,successCallback, errorCallback){
			    var id= this.id;
				var _p = _f[p];
				exec(successCallback, errorCallback, "Interstitial", _p, [id, options]);
			}
		})(prop);
	 };

	 for (var prop in _callbacks) {
		(function(p) {
			Interstitial.prototype[prop] = function(successCallback, errorCallback){
			    var id= this.id;
				var _p = _callbacks[p];
				exec(successCallback, errorCallback, "Interstitial", _p, [id]);
			}
		})(prop);
	 };

module.exports = Interstitial;

});
