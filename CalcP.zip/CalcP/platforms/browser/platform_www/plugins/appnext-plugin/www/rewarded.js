cordova.define("appnext-plugin.rewarded", function(require, exports, module) { 	var
		exec = require('cordova/exec'),
		cordova = require('cordova');

	var _f ={
		setCategories:'setCategories',
		setPostback:'setPostback',
		setButtonText:'setButtonText',
		setButtonColor:'setButtonColor',
		setPreferredOrientation:'setOrientation',
		setMute:'setMute',
		setBackButtonCanClose:'setBackButtonCanClose',

		setProgressType:'setProgressType',
		setVideoLength:'setVideoLength',
		setProgressColor:'setProgressColor',
		setRewardsTransactionId:'setRewardsTransactionId',
		setRewardsUserId:'setRewardsUserId',
		setRewardsAmountRewarded:'setRewardsAmountRewarded',
		setRewardsCustomParameter:'setRewardsCustomParameter',
		setRewardsRewardTypeCurrency:'setRewardsRewardTypeCurrency'
	}
	var _callbacks={
		loadAd:'loadAd',
		showAd:'showAd',
		setOnAdClickedCallback:'setOnAdClickedCallback',
		setOnAdErrorCallback:'setOnAdErrorCallback',
		setOnAdLoadedCallback:'setOnAdLoadedCallback',
		setOnAdClosedCallback:'setOnAdClosedCallback',
		setOnVideoEndedCallback:'setOnVideoEndedCallback'
	}
	function Rewarded(placementId,config) {
	    this.id = "ARId_"+Date.now();
		this.placementId = placementId;
		this.config=config||null;
		exec(function(){}, function(){}, "Rewarded", "create", [this.id, placementId, config]);
	}
	
	Rewarded.prototype['setShowClose'] = function(showclose, delay, successCallback, errorCallback){
		var id= this.id;
		delay=delay||0;
		exec(successCallback, errorCallback, "Rewarded", 'setShowClose', [id, showclose, delay]);
	}

	 for (var prop in _f) {
		(function(p) {
			Rewarded.prototype[prop] = function(options,successCallback, errorCallback){
			    var id= this.id;
				var _p = _f[p];
				exec(successCallback, errorCallback, "Rewarded", _p, [id, options]);
			}
		})(prop);
	 };

	 for (var prop in _callbacks) {
		(function(p) {
			Rewarded.prototype[prop] = function(successCallback, errorCallback){
			    var id= this.id;
				var _p = _callbacks[p];
				exec(successCallback, errorCallback, "Rewarded", _p, [id]);
			}
		})(prop);
	 };

module.exports = Rewarded;


});
