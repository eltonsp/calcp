// Initialize your app
var myApp = new Framework7({
    swipePanel: 'left'
});
// Export selectors engine
var $$ = Dom7;
var mainView = myApp.addView('.view-main', {
    dynamicNavbar: true
});
$$('#open-panel').on('click', function () {
    myApp.openPanel('left');
});
$$('#panel-close').on('click', function () {
    myApp.closePanel();
});
$$("#lag").click(function () {
    window.location.href = "lagrange.html";
});
$$("#inter").click(function () {
    window.location.href = "interpolacao.html";
});
$$("#newC").click(function () {
    window.location.href = "newtonCotes.html";
});
/////// INTERPOLAÇÃO /////////////////////
$$("#calcI").submit(function (e) {
    e.preventDefault();
    var x0 = $("#x0").val();
    var x1 = $("#x1").val();
    var x2 = $("#x2").val();
    var fx0 = $("#fx0").val();
    var fx1 = $("#fx1").val();
    var fx2 = $("#fx2").val();
    var fend = $('#fend').val();
    var casasD = $("#casasD").val();
    var list = "";
    casasD = parseInt(casasD);
    x0 = parseFloat(x0);
    x1 = parseFloat(x1);
    x2 = parseFloat(x2);
    fx0 = parseFloat(fx0);
    fx1 = parseFloat(fx1);
    fx2 = parseFloat(fx2);
    //Tabela inicial
    list += x0 + '<sup>2</sup> a + (' + x0 + '<sup>1</sup> b) + (' + x0 + '<sup>0</sup> c ) = ' + fx0 + '</br>';
    list += x1 + '<sup>2</sup> a + (' + x1 + '<sup>1</sup> b) + (' + x1 + '<sup>0</sup> c ) = ' + fx1 + '</br>';
    list += x2 + '<sup>2</sup> a + (' + x2 + '<sup>1</sup> b) + (' + x2 + '<sup>0</sup> c ) = ' + fx2 + '</br>';
    list += '<hr>';
    //a
    var a0 = Math.pow(x0, 2);
    var a1 = Math.pow(x1, 2);
    var a2 = Math.pow(x2, 2);
    //b repete x1
    var b0 = x0;
    var b1 = x1;
    var b2 = x2;
    //c
    var c0 = Math.pow(x0, 0);
    var c1 = Math.pow(x1, 0);
    var c2 = Math.pow(x2, 0);
    //MOSTRA A TABELA COM OS CALCULANDO OS EXPOENTES
    list += c0 + '  &nbsp; &nbsp; &nbsp; ' + b0 + '  &nbsp; &nbsp; &nbsp; ' + a0 + ' &nbsp; &nbsp; &nbsp; ' + fx0 + '<br>';
    list += c1 + ' &nbsp; &nbsp; &nbsp; ' + b1 + ' &nbsp; &nbsp; &nbsp; ' + a1 + ' &nbsp; &nbsp; &nbsp; ' + fx1 + '<br>';
    list += c2 + ' &nbsp; &nbsp; &nbsp; ' + b2 + ' &nbsp; &nbsp; &nbsp; ' + a2 + ' &nbsp; &nbsp; &nbsp; ' + fx2 + '<br>';
    list += '<hr>';
    ///terceira parte
    list += c0 + ' &nbsp; &nbsp; &nbsp; ' + b0 + ' &nbsp; &nbsp; &nbsp; ' + a0 + ' &nbsp; &nbsp; &nbsp; ' + fx0 + '<br>';
    if (c0 >= 0) {
        c1 = ((c0 * (-c0)) + (c1));
        c1 = c1.toFixed(casasD);
        b1 = ((b0 * (-c0)) + (b1));
        b1 = b1.toFixed(casasD);
        a1 = ((a0 * (-c0)) + (a1));
        a1 = a1.toFixed(casasD);
        fx1 = ((fx0 * (-c0)) + (fx1));
        fx1 = fx1.toFixed(casasD);
        /////////////////////////////
        //terceira linha
        ////////////////////////////
        c2 = ((c0 * (-c0)) + (c2));
        c2 = c2.toFixed(casasD);
        b2 = ((b0 * (-c0)) + (b2));
        b2 = b2.toFixed(casasD);
        a2 = ((a0 * (-c0)) + (a2));
        a2 = a2.toFixed(casasD);
        fx2 = ((fx0 * (-c0)) + (fx2));
        fx2 = fx2.toFixed(casasD);
    } else {
        c1 = ((c0 * (+c0)) + (c1));
        c1 = c1.toFixed(casasD);
        b1 = ((b0 * (+c0)) + (b1));
        b1 = b1.toFixed(casasD);
        a1 = ((a0 * (+c0)) + (a1));
        a1 = a1.toFixed(casasD);
        fx1 = ((fx0 * (+c0)) + (fx1));
        fx1 = fx1.toFixed(casasD);
        //////////////////////////////////
        ///terceira linha 
        /////////////////////////////////
        c2 = ((c0 * (+c0)) + (c2));
        c2 = c2.toFixed(casasD);
        b2 = ((b0 * (+c0)) + (b2));
        b2 = b2.toFixed(casasD);
        a2 = ((a0 * (+c0)) + (a2));
        a2 = a2.toFixed(casasD);
        fx2 = ((fx0 * (+c0)) + (fx2));
        fx2 = fx2.toFixed(casasD);
    }
    list += c1 + ' &nbsp; &nbsp; &nbsp; ' + b1 + ' &nbsp; &nbsp; &nbsp; ' + a1 + ' &nbsp; &nbsp; &nbsp; ' + fx1 + '<br>';
    list += c2 + ' &nbsp; &nbsp; &nbsp; ' + b2 + ' &nbsp; &nbsp; &nbsp; ' + a2 + ' &nbsp; &nbsp; &nbsp; ' + fx2 + '<br>';
    list += '<hr>';
/////////////////////////////////////////////////////////////////////////////////
////quarta parte 

    list += c0 + ' &nbsp; &nbsp; &nbsp; ' + b0 + ' &nbsp; &nbsp; &nbsp; ' + a0 + ' &nbsp; &nbsp; &nbsp; ' + fx0 + '<br>';
    a1 = (a1 * (1 / b1));
    a1 = a1.toFixed(casasD);
    fx1 = (fx1 * (1 / b1));
    fx1 = fx1.toFixed(casasD);
    c1 = (c1 * (1 / b1));
    c1 = c1.toFixed(casasD);
    b1 = (b1 * (1 / b1));
    b1 = b1.toFixed(casasD);
    list += c1 + ' &nbsp; &nbsp; &nbsp; ' + b1 + ' &nbsp; &nbsp; &nbsp; ' + a1 + ' &nbsp; &nbsp; &nbsp; ' + fx1 + '<br>';
    list += c2 + ' &nbsp; &nbsp; &nbsp; ' + b2 + ' &nbsp; &nbsp; &nbsp; ' + a2 + ' &nbsp; &nbsp; &nbsp; ' + fx2 + '<br>';
    list += '<hr>';
    if (c0 >= 0) {
        a0 = ((a1 * (-b0)) + (a0)); //calcula a1
        fx0 = ((fx1 * (-b0)) + (fx0)); //calcula funcao 1
        b0 = ((b1 * (-b0)) + (b0)); //calcula b1
        c0 = ((c1 * (-b0)) + (c0)); //zera c1

    } else {
        a0 = ((a1 * (+b0)) + (a0)); //calcula a1
        fx0 = ((fx1 * (+b0)) + (fx0)); //calcula funcao 1
        b0 = ((b1 * (+b0)) + (b0)); //calcula b1
        c0 = ((c1 * (+b0)) + (c0)); //zera c1

    }
    list += c0 + ' &nbsp; &nbsp; &nbsp; ' + b0 + ' &nbsp; &nbsp; &nbsp; ' + a0 + ' &nbsp; &nbsp; &nbsp; ' + fx0 + '<br>';
    list += c1 + ' &nbsp; &nbsp; &nbsp; ' + b1 + ' &nbsp; &nbsp; &nbsp; ' + a1 + ' &nbsp; &nbsp; &nbsp; ' + fx1 + '<br>';
    if (b2 >= 0) {

        a2 = parseInt(a2);
        a2 = (a1 * (-b2) + a2); //calcula a1

        fx2 = parseInt(fx2);
        fx2 = ((fx1 * (-b2)) + fx2); //calcula funcao 1

        c2 = parseInt(c2);
        c2 = ((c1 * (-b2)) + c2); //zera c1

        b2 = parseInt(b2);
        b2 = ((b1 * (-b2)) + b2); //calcula b1

    } else {
        a2 = parseInt(a2);
        a2 = ((a1 * (+b2)) + (a2)); //calcula a1 

        fx2 = parseInt(fx2);
        fx2 = ((fx1 * (+b2)) + (fx2)); //calcula funcao 1

        c2 = parseInt(c2);
        c2 = ((c1 * (+b2)) + (c2)); //zera c1

        b2 = parseInt(b2);
        b2 = ((b1 * (+b2)) + (b2)); //calcula b1
    }
    list += c2 + ' &nbsp; &nbsp; &nbsp; ' + b2 + ' &nbsp; &nbsp; &nbsp; ' + a2 + ' &nbsp;&nbsp;&nbsp; ' + fx2 + '<br>';
    list += '<hr>';
    list += a2 + 'a = ' + fx2 + '<br>';
    var si = '0';
    if (a1 >= 0) {
        si = ' + ';
    }

    list += 'b';
    if (si !== '0') {
        list += si;
    }

    list += a1 + 'a = ' + fx1 + '<br>';
    var sic = '0';
    if (a0 >= 0) {
        sic = ' + ';
    }
    list += 'c ';
    if (sic !== '0') {
        list += sic;
    }
    list += a0 + 'a = ' + fx0 + '<br>';
    var fna = (fx2) / (+a2);
    fna = fna.toFixed(casasD);
    var fnb = (fx1 - (a1 * fna));
    fnb = fnb.toFixed(casasD);
    var res = a0 * fna;
    var fnc = (fx0 - res);
    fnc = fnc.toFixed(casasD);
    //MONTA A FUNÇAO POLIMINAL COM OS X

    var sinal = '0';
    if (fnb >= 0) {
        sinal = ' + ';
    }

    var sinal2 = 0;
    if (fnc >= 0) {
        sinal2 = ' + ';
    }
    list += fna + '<sup>2</sup> ';
    if (sinal !== '0') {
        list += sinal;
    }
    list += fnb + 'x ';
    if (sinal2 !== '0') {
        list += sinal2;
    }
    list += fnc + '<br>';
    //MONTA A FUNÇAO POLIMINAL TROCANDO OS X PELO VALOR DA FUNÇAO FINAL
    var sinal = '0';
    if (fnb >= 0) {
        sinal = ' + ';
    }

    var sinal2 = '0';
    if (fnc >= 0) {
        sinal2 = ' + ';
    }
    list += '<br>' + fna + ' x ' + fend + ' <sup>2</sup> ';
    if (sinal !== '0') {
        list += sinal;
    }
    list += fnb + ' * ' + fend;
    if (sinal2 !== '0') {
        list += sinal2;
    }
    list += fnc + '<br>';
    fend = parseFloat(fend);
    fna = parseFloat(fna);
    fnb = parseFloat(fnb);
    fnc = parseFloat(fnc);
    var n2 = Math.pow(fend, 2);
    n2 = parseFloat(n2);
    res = (fna * n2) + (fnb * fend) + fnc;
    res = res.toFixed(casasD);
    list += '<br>' + res;
    $("#cont").html(list);
});
///////////FIM INTERPOLAÇÃO /////////////////


//////////LAGRANGE /////////////////////////////
$$("#calcL").submit(function (e) {
    e.preventDefault();
    var x0 = $("#x0").val();
    var x1 = $("#x1").val();
    var x2 = $("#x2").val();
    var fx0 = $("#fx0").val();
    var fx1 = $("#fx1").val();
    var fx2 = $("#fx2").val();
    var fend = $('#fend').val();
    var casasD = $("#casasD").val();
    var list = "";
    casasD = parseInt(casasD);
    x0 = parseFloat(x0);
    x1 = parseFloat(x1);
    x2 = parseFloat(x2);
    fx0 = parseFloat(fx0);
    fx1 = parseFloat(fx1);
    fx2 = parseFloat(fx2);
    //Tabela inicial
    var list = "";
////INICIO DA PRIMEIRA PARTE
//////primeira linha
    list += '(x -' + x1 + ')*(x - ' + x2 + ') / (' + x0 + ' - ' + x1 + ') * (' + x0 + ' - ' + x2 + ')';
    list += ' = ' + fx0 + '<br>';
//
    var calcn1 = ((-(x1) + (-(x2))));
    calcn1 = calcn1.toFixed(casasD);
    var calcn2 = (-(x1) * (-x2));
    calcn2 = calcn2.toFixed(casasD);
    var sinal2 = '0';
    var sinal1 = '0';
    if (calcn2 > 0) {
        sinal2 = '+ ';
    }
    if (calcn1 > 0) {
        sinal1 = '+ ';
    }

/////segunda linha
    list += 'x<sup>2</sup> ';
    if (sinal1 !== '0') {
        list += sinal1 + calcn1 + ' x ';
    } else {
        list += calcn1 + ' x ';
    }

    if (sinal2 !== '0') {
        list += sinal2 + calcn2;
    } else {
        list += calcn2;
    }

    var calc3 = ((x0) - (x1));
    calc3 = calc3.toFixed(casasD);
    var calc4 = ((x0) - (x2));
    calc4 = calc4.toFixed(casasD);
    var calc34 = ((calc3) * (calc4));
    calc34 = calc34.toFixed(casasD);
    list += ' / ' + calc34 + ' = ' + fx0 + '<br>';
    var nx2 = ((fx0) / (calc34));
    nx2 = nx2.toFixed(casasD);
    var xb = ((nx2) * (calcn1));
    xb = xb.toFixed(casasD);
    var xc = ((nx2) * (calcn2));
    xc = xc.toFixed(casasD);
    /////terceira linha
    list += (x2) + 'x<sup>2</sup>';
    var sinalxb = '0';
    if (xb > 0) {
        sinalxb = '+ ';
    }

    var sinalxc = '0';
    if (xc > 0) {
        sinalxc = '+ ';
    }

    if (sinalxb !== '0') {
        list += sinalxb + (xb) + ' x ';
    } else {
        list += (xb) + ' x ';
    }
    if (sinalxc !== '0') {
        list += sinalxc + (xc);
        var resC = xc;
        resC = parseFloat(resC);
    } else {
        (xc);
        var resC = xc;
        resC = parseFloat(resC);
    }

    var resA = nx2;
    resA = parseFloat(resA);
    var resB = xb;
    resB = parseFloat(resB);
    list += '<hr>';
/////FIM DA PRIMEIRA PARTE 

////SEGUNDA PARTE
    list += '(x -' + x0 + ')*(x - ' + x2 + ' / (' + x1 + ' - ' + x0 + ') * (' + x1 + ' - ' + x2 + ')';
    list += ' = ' + fx1 + '<br>';
    calcn1 = (-(x0) + (-(x2)));
    calcn1 = calcn1.toFixed(casasD);
    calcn2 = (-(x0) * (-(x2)));
    calcn2 = calcn2.toFixed(casasD);
    sinal2 = '0';
    if (calcn2 > 0) {
        sinal2 = '+ ';
    }

    sinal1 = '0';
    if (calcn1 > 0) {
        sinal1 = '+ ';
    }

    list += 'x<sup>2</sup> ';
    if (sinal1 !== '0') {
        list += sinal1 + calcn1 + ' x ';
    } else {
        list += calcn1 + ' x ';
    }
    if (sinal2 !== '0') {
        list += sinal2 + calcn2;
    } else {
        list += calcn2;
    }
    calc3 = ((x1) - (x0));
    calc3 = calc3.toFixed(casasD);
    calc4 = ((x1) - (x2));
    calc4 = calc4.toFixed(casasD);
    calc34 = ((calc3) * (calc4));
    list += ' / ' + calc34 + ' = ' + fx1 + '<br>';
    nx2 = ((fx1) / (calc34));
    nx2 = nx2.toFixed(casasD);
    xb = ((nx2) * (calcn1));
    xb = xb.toFixed(casasD);
    xc = ((nx2) * (calcn2));
    xc = xc.toFixed(casasD);
    list += nx2 + 'x<sup>2</sup>';
    var sinalxb = '0';
    if (xb > 0) {
        sinalxb = '+ ';
    }
    var sinalxc = '0';
    if (xc > 0) {
        sinalxc = '+ ';
    }

    if (sinalxb !== '0') {
        list += sinalxb + xb + ' x ';
    } else {
        list += xb + ' x ';
    }
    if (sinalxc !== '0') {
        list += sinalxc + xc;
        var resC1 = xc;
        resC1 = parseFloat(resC1);
    } else {
        list += xc;
        var resC1 = xc;
        resC1 = parseFloat(resC1);
    }

    list += '<hr>';
/////FIM DA SEGUNDA PARTE
    var resA1 = nx2;
    resA1 = parseFloat(resA1);
    var resB1 = xb;
    resB1 = parseFloat(resB1);
////INICIO DA TERCEIRA PARTE 
    list += '(x -' + x0 + ')*(x - ' + x1 + ' / (' + x2 + ' - ' + x0 + ') * (' + x2 + ' - ' + x1 + ')';
    list += ' = ' + fx2 + '<br>';
    calcn1 = (-(x0) + (-(x1)));
    calcn1 = calcn1.toFixed(casasD);
    calcn2 = (-(x0) * (-(x1)));
    calcn2 = calcn2.toFixed(casasD);
    sinal2 = '0';
    if (calcn2 >= 0) {
        sinal2 = '+ ';
    }
    sinal1 = '0';
    if (calcn1 >= 0) {
        sinal1 = '+ ';
    }

    list += 'x<sup>2</sup> ';
    if (sinal1 !== '0') {
        list += sinal1 + calcn1 + ' x ';
    } else {
        list += calcn1 + ' x ';
    }
    if (sinal2 !== '0') {
        list += sinal2 + calcn2;
    } else {
        list += calcn2;
    }

    calc3 = ((x2) - (x0));
    calc3 = calc3.toFixed(casasD);
    calc4 = ((x2) - (x1));
    calc4 = calc4.toFixed(casasD);
    calc34 = ((calc3) * (calc4));
    calc34 = calc34.toFixed(casasD);
    list += ' / ' + calc34 + ' = ' + fx2 + '<br>';
    nx2 = ((fx2) / (calc34));
    nx2 = nx2.toFixed(casasD);
    xb = ((nx2) * (calcn1));
    xb = xb.toFixed(casasD);
    xc = ((nx2) * (calcn2));
    xc = xc.toFixed(casasD);
    list += nx2 + 'x<sup>2</sup>';
    sinalxb = '0';
    if (xb >= 0) {
        sinalxb = '+ ';
    }
    sinalxc = '0';
    if (xc >= 0) {
        sinalxc = '+ ';
    }

    if (sinalxb !== '0') {
        list += sinalxb + xb + ' x ';
    } else {
        list += xb + ' x ';
    }
    if (sinalxc !== '0') {
        list += sinalxc + xc;
        var resC2 = xc;
        resC2 = parseFloat(resC2);
    } else {
        list += xc;
        var resC2 = xc;
        resC2 = parseFloat(resC2);
    }

    list += '<hr>';
    var resA2 = nx2;
    resA2 = parseFloat(resA2);
    var resB2 = xb;
    resB2 = parseFloat(resB2);
////FIM DA TERCEIRA PARTE

////// PARTES FINAIS ///////////////

    var ress1 = (resA + resA1 + resA2);
    ress1 = ress1.toFixed(casasD);
    ress1 = parseFloat(ress1);
    var ress2 = (resB + resB1 + resB2);
    ress2 = ress2.toFixed(casasD);
    ress2 = parseFloat(ress2);
    var ress3 = (resC + resC1 + resC2);
    ress3 = ress3.toFixed(casasD);
    ress3 = parseFloat(ress3);
    list += ' <br>';
    list += 'Polinomio Interpolador p(x) : <br>';
    list += ress1 + 'x<sup>2</sup> + ' + ress2 + 'x + ' + ress3;
    list += '<hr>';
    list += ' <br>';
    list += ress1 + ' * ' + fend + '<sup>2</sup> + ' + ress2 + ' * ' + fend + ' + ' + ress3;
    list += '<hr>';
    var fep2 = Math.pow(fend, 2);
    fep2 = fep2.toFixed(casasD);
    fep2 = parseFloat(fep2);
    var res = (ress1 * fep2) + (ress2 * fend) + (ress3);
    res = res.toFixed(casasD);
    list += res;
    $("#cont").html(list);
});
///////////////////////////
/// NEWTON-COTES

$$("#calcNC").submit(function (e) {
    e.preventDefault();
    var b = $("#b").val();
    var a = $("#a").val();
    var n = $("#n").val();
    var divid = $("#divid").val();
    var divis = $("#divis").val();
    var expo = $("#expo").val();
    var ax2 = $("#ax2").val();
    var bx = $('#bx').val();
    var cx = $('#cx').val();
    var casasD = $("#casasD").val();
    var list = "";
    casasD = parseInt(casasD);
    b = parseFloat(b);
    a = parseFloat(a);
    n = parseFloat(n);
    divid = parseFloat(divid);
    divis = parseFloat(divis);
    ax2 = parseFloat(ax2);
    bx = parseFloat(bx);
    cx = parseFloat(cx);
    bx = parseFloat(bx);
    expo = parseInt(expo);
    //Tabela inicial
    var list = "";
////INICIO DA PRIMEIRA PARTE
//////primeira linha

    var h = (b - a) / n;
    var x0 = a;
    var x1 = x0 + h;
    var x2 = b;
    list += 'X0 = ' + x0 + '<br>  X1 = ' + x1 + '<br>  X2 = ' + x2 + '<hr>';
    var px0 = divid / (Math.pow(x0, expo) + divis);
    px0 = px0.toFixed(casasD);
    px0 = parseFloat(px0);
    var px1 = divid / (Math.pow(x1, expo) + divis);
    px1 = px1.toFixed(casasD);
    px1 = parseFloat(px1);
    var px2 = divid / (Math.pow(x2, expo) + divis);
    px2 = px2.toFixed(casasD);
    px2 = parseFloat(px2);
    list += 'FX0 = ' + px0 + '<br>  FX1 = ' + px1 + '<br>  FX2 = ' + px2 + '<hr>';
    list += ax2 + ' * x <sup> 2 + ' + a + '</sup> / ' + ' 2 + ' + a + ' + ' + bx + ' x <sup> 1 + ' + a + '</sup> / 1 + ' + a + ' + ' + cx + ' x <hr>';
    var res1 = ax2 / (2 + a);
    res1 = res1.toFixed(casasD);
    res1 = parseFloat(res1);
    var res2 = bx / (1 + a);
    res2 = res2.toFixed(casasD);
    res2 = parseFloat(res2);
    var res3 = cx;
    res3 = res3.toFixed(casasD);
    res3 = parseFloat(res3);
    list += res1 + 'x <sup> ' + (2 + a) + '</sup> + ' + res2 + 'x <sup> ' + (1 + a) + '</sup> + ' + cx + 'x <hr>';
    var expoa = 2 + a;
    expoa = parseInt(expoa); //3


    var expob = 1 + a; //2
    expob = parseInt(expob);
    list += '(' + res1 + '*' + b + '<sup> ' + expoa + '</sup> + ' + res2 + '*' + b + '<sup>' + expob + '</sup> + ' + res3 + '*' + b + ') - (' + res1 + '*' + a + '<sup> ' + expoa + '</sup> + ' + res2 + '*' + a + '<sup>' + expob + '</sup> + ' + res3 + '*' + a + ') <hr>';
    var ba = Math.pow(b, expoa);
    ba = parseInt(ba);
    var nres1 = res1 * (ba);
    nres1 = nres1.toFixed(casasD);
    nres1 = parseFloat(nres1);
    var bb = Math.pow(b, expob);
    bb = parseInt(bb);
    var nres2 = res2 * (bb);
    nres2 = nres2.toFixed(casasD);
    nres2 = parseFloat(nres2);
    var nres3 = res3 * b;
    nres3 = nres3.toFixed(casasD);
    nres3 = parseFloat(nres3);
    var aa = Math.pow(a, expoa);
    aa = parseInt(aa);
    var nres1a = res1 * (aa);
    nres1a = nres1a.toFixed(casasD);
    nres1a = parseFloat(nres1a);
    var ab = Math.pow(a, expob);
    ab = parseInt(ab);
    var nres2a = res2 * (ab);
    nres2a = nres2a.toFixed(casasD);
    nres2a = parseFloat(nres2a);
    var nres3a = res3 * a;
    nres3a = nres3a.toFixed(casasD);
    nres3a = parseFloat(nres3a);
    var resf = nres1 + (nres2) + (nres3);
    var resf1 = nres1a + (nres2a) + (nres3a);
    list += resf - resf1;
    $("#cont").html(list);
});


admob.setOptions({
    publisherId: "ca-app-pub-XXXXXXXXXXXXXXXX/BBBBBBBBBB", // Required
    interstitialAdId: "ca-app-pub-XXXXXXXXXXXXXXXX/IIIIIIIIII", // Optional
    tappxIdiOS: "/XXXXXXXXX/Pub-XXXX-iOS-IIII", // Optional
    tappxIdAndroid: "/XXXXXXXXX/Pub-XXXX-Android-AAAA", // Optional
    tappxShare: 0.5                                        // Optional
});

admob.createBannerView({
    autoShowBanner: true
});

function callMeToShowBanners() {
    admob.showBannerAd(true);
}